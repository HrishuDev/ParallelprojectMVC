package com.cg.SpringBatch;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class PersonsFieldSetMapper implements FieldSetMapper<Persons>
{
	static Persons persons;
	public Persons mapFieldSet(FieldSet fieldSet) throws BindException 
	{
		persons.setFirstName(fieldSet.readString(1));
		persons.setLastName(fieldSet.readString(2));
		persons.setEmail(fieldSet.readString(3));
		persons.setAge(fieldSet.readInt(4));
		return persons;
	}
	
}
