package com.cg.spring.bean;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@SequenceGenerator(name="TransIDSequence", initialValue=1, allocationSize=246576)
@Table(name="Transactions")
public class Transaction {
		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TransIDSequence")
		private int transactionid;
		private Date dateoftransaction;
		private Timestamp timeoftransaction;
		private int accountnumber;
		private double amount;
		private String type;
		public int getTransactionid() {
			return transactionid;
		}
		public void setTransactionid(int transactionid) {
			this.transactionid = transactionid;
		}
		public Date getDateoftransaction() {
			return dateoftransaction;
		}
		public void setDateoftransaction(Date dateoftransaction) {
			this.dateoftransaction = dateoftransaction;
		}
		public Timestamp getTimeoftransaction() {
			return timeoftransaction;
		}
		public void setTimeoftransaction(Timestamp timeoftransaction) {
			this.timeoftransaction = timeoftransaction;
		}
		public int getAccountnumber() {
			return accountnumber;
		}
		public void setAccountnumber(int accountnumber) {
			this.accountnumber = accountnumber;
		}
		public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		@Override
		public String toString() {
			return "Transaction-> Transaction ID: " + transactionid + ", Account Number: " + accountnumber + ", Amount: "
					+ amount + ", Type: " + type + ", Date Of Transaction: " + dateoftransaction
					+ ", Time Of Transaction: " + timeoftransaction + "\n";
		}
		
}
