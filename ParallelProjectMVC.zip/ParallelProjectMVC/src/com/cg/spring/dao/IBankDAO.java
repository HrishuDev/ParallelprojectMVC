package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.bean.Account;
import com.cg.spring.bean.Transaction;
import com.cg.spring.exception.BankException;

public interface IBankDAO {
	void addAccount(Account account) throws BankException;
	Account getAccountDetails(int accountnumber) throws BankException;
	Transaction depositAmount(int accountnumber, double amount) throws BankException;
	Transaction withdrawAmount(int accountnumber, int pin, double amount) throws BankException;
    boolean Moneytransfer(int accountnumber, int pin, int accountnumber2, double amount) throws BankException;
	List<Transaction> showTransactions(int accountnumber, int pin);
}
