package com.cg.spring.dao;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.bean.Account;
import com.cg.spring.bean.Transaction;
import com.cg.spring.exception.BankException;


@Repository
public class BankDAOImpl implements IBankDAO{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void addAccount(Account account) throws BankException {
		if(account==null) {
			throw new BankException("##### Bank Exception: CANNOT ADD NEW ACCOUNT #####");
		}
		try {
			entityManager.persist(account);
			entityManager.flush();
		}	
		catch(Exception e){
			throw new BankException("Exception In DAO Add Trainee: "+ e.getMessage());
		}
	}

	@Override
	public Account getAccountDetails(int accountnumber) throws BankException {
		try {
			Account account=entityManager.find(Account.class, accountnumber);
			entityManager.flush();
			return account;
		}
		catch(Exception e){
			throw new BankException("Exception In DAO Get Account Details: "+ e.getMessage());
		}
	}

	@Override
	public Transaction depositAmount(int accountnumber, double amount) throws BankException 
	{
			Account account=entityManager.find(Account.class, accountnumber);
			Transaction transaction=new Transaction();
			if(account!=null)
			{
				account.setBalance(account.getBalance()+amount);
				transaction.setAccountnumber(account.getAccountnumber());
				transaction.setAmount(amount);
				transaction.setDateoftransaction(Date.valueOf(LocalDate.now()));
				transaction.setTimeoftransaction(Timestamp.valueOf(LocalDateTime.now()));
				transaction.setType("Deposit");
				entityManager.persist(transaction);
				entityManager.flush();
			}
			
			return transaction;
	}

	@Override
	public Transaction withdrawAmount(int accountnumber, int pin, double amount) throws BankException {
		Account account=entityManager.find(Account.class, accountnumber);
		Transaction transaction=new Transaction();
		if(account!=null)
		{
			if(amount<=account.getBalance()-500)
			{
				account.setBalance(account.getBalance()-amount);
				transaction.setAccountnumber(account.getAccountnumber());
				transaction.setAmount(amount);
				transaction.setDateoftransaction(Date.valueOf(LocalDate.now()));
				transaction.setTimeoftransaction(Timestamp.valueOf(LocalDateTime.now()));
				transaction.setType("Withdraw");
				entityManager.persist(transaction);
				entityManager.flush();
			}
			else
			{
				return null;
			}
			
		}
		return transaction;
	}

	@Override
	public boolean Moneytransfer(int accountnumber, int pin, int accountnumber2, double amount) throws BankException {
		Account account=entityManager.find(Account.class, accountnumber);
		Transaction transaction=new Transaction();
		Account account2=entityManager.find(Account.class, accountnumber2);
		Transaction transaction2=new Transaction();
		if(account!=null && account2!=null)
		{
			if(amount<=account.getBalance()-500)
			{
				account.setBalance(account.getBalance()-amount);
				transaction.setAccountnumber(account.getAccountnumber());
				transaction.setAmount(amount);
				transaction.setDateoftransaction(Date.valueOf(LocalDate.now()));
				transaction.setTimeoftransaction(Timestamp.valueOf(LocalDateTime.now()));
				transaction.setType("Transfer To "+account2.getAccountnumber());
				entityManager.persist(transaction);
				entityManager.flush();
				
				account2.setBalance(account2.getBalance()+amount);
				transaction2.setAccountnumber(account2.getAccountnumber());
				transaction2.setAmount(amount);
				transaction2.setDateoftransaction(Date.valueOf(LocalDate.now()));
				transaction2.setTimeoftransaction(Timestamp.valueOf(LocalDateTime.now()));
				transaction2.setType("Transfer From "+account.getAccountnumber());
				entityManager.persist(transaction2);
				entityManager.flush();
				return true;
			}
			else
			{
				return false;
			}
			
		}
		return false;
	}

	@Override
	public List<Transaction> showTransactions(int accountnumber, int pin) {
		try {
			TypedQuery<Transaction> query = entityManager.createQuery("SELECT transactions FROM Transaction transactions WHERE transactions.accountnumber=:ano", Transaction.class);
			query.setParameter("ano", accountnumber);
			return query.getResultList();
		}	
		catch(Exception e){
			throw new BankException("Bank Exception: In DAO: Get All Transactions: "+ e.getMessage());
		}
	}

}
